#!/usr/bin/env python3
from pathlib import Path
from urllib.request import Request, urlopen
import re

INDEX = "https://www.nhc.noaa.gov/data/hurdat/"
OUT = Path(__file__).resolve().parents[1] / "data"
OUT.mkdir(parents=True, exist_ok=True)

def get(url):
    req = Request(url, headers={"User-Agent": "TropicalCycloneExplorer/1.0 (GitHub data updater)"})
    with urlopen(req, timeout=60) as r:
        return r.read()

html = get(INDEX).decode("utf-8", "replace")

def latest(pattern):
    names = re.findall(r'href="([^"]+)"', html, flags=re.I)
    candidates = [n for n in names if re.fullmatch(pattern, n)]
    if not candidates:
        raise RuntimeError(f"No NHC file matched: {pattern}")
    # Filenames contain season/update dates; lexicographic order works for current naming.
    return sorted(candidates)[-1]

atl = latest(r"hurdat2-1851-\d{4}-\d{6}\.txt")
pac = latest(r"hurdat2-nepac-1949-\d{4}-\d{6}\.txt")

for remote, local in [(atl, "atlantic.txt"), (pac, "pacific.txt")]:
    print(f"Downloading {remote} -> data/{local}")
    data = get(INDEX + remote)
    (OUT / local).write_bytes(data)

print("Done.")
